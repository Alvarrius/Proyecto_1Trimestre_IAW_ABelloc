PARA COMPROBAR EL CORRECTO FUNCIONAMIENTO DE ESTA PAGINA WEB SE NECESITA:

- Tener activado un servidor apache en localhost
- Tener activado MYSQL
- Importar la base de datos "cpus_alvarrius.sql" de la carpeta "Base_Datos" a PHPMyAdmin

CREDENCIALES PARA INICIAR SESION:

Usuario "alu"
Password "123"

Link del Github:
https://github.com/Alvarrius/Proyecto_1Trimestre_IAW_ABelloc.git
