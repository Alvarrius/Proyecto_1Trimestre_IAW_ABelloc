<?php include("cabecera_pie/cabeza_admin.php"); ?>

    <div align="center"><img src='../Imagenes/logos/sudor.png' width="5%" height="auto" alt='Cpus'/>   <img src='../Imagenes/logos/diablo.png' width="5%" height="auto" alt='Cpus'/>
    <div align="center"><img src='../Imagenes/logos/adminllegando.gif' width="23%" height="auto" alt='Cpus'/>  <img src='../Imagenes/logos/admin-mode-activated.jpg' width="35%" height="auto" alt='Cpus'/></div>
          
       


<?php include("cabecera_pie/pie_admin.php"); ?>