<?php include("../cabecera_pie/cabeza_admin.php"); ?>

<div class="pricing-header p-3 pb-md-4 mx-auto text-center">
        <h1 class="display-4 fw-normal">PEDIDOS <img src='../../Imagenes/logos/stonks.gif' width="125" alt='Cpus'/></h1>
  </div>

<?php include("../cabecera_pie/pie_admin.php"); ?>