  <footer class="pt-4 my-md-5 pt-md-5 border-top">
    <div class="row text-center">
      <div class="col-12 col-md">
        <img class="mb-2" src="../Imagenes/logos/wolf.png" alt="" width="24" height="19"> Alvarrius Corp. &copy; 2005-2022<small class="d-block mb-3 text-muted"></small>
        
      </div>
    </div>
  </footer>
  </div>
  </div>
</div>

  </body>
</html>